#pragma once
void insymbol();
void lexical_init();
int lexical_main();