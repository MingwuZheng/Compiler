#pragma once
void program();
void constdec();
void vardec();
void statement();
void ifstatement();
void whilestatement();
void forstatement();
void compoundstatement();
void scanstatement();
void printstatement();
string call(int pos);
void assignment();
int paralist();
string factor(bool*);
string term(bool*);
string expression(bool*);
string condition();
